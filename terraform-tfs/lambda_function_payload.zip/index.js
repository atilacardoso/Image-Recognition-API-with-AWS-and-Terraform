// index.js

const AWS = require('aws-sdk');
const rekognition = new AWS.Rekognition();

exports.handler = async (event) => {
    // Your Amazon Rekognition code here
};
